export function randemDate(start, d) {
    const h = Math.floor(Math.random() * 11 + 1)
        .toString()
        .padStart(2, "0");
    const m = Math.floor(Math.random() * 60)
        .toString()
        .padStart(2, "0");

    const newDate = new Date(`${start}T${h}:${m}:20Z`);

    newDate.setDate(newDate.getDate() + d);

    

    return newDate.toISOString()
}

export function dayDifference(sDate) {
    
    const specificDate = new Date(sDate);

    
    const currentDate = new Date();

    
    const timeDifference = currentDate - specificDate;

    
    const dayDifference = Math.floor(timeDifference / (1000 * 60 * 60 * 24));

    // console.log(
    //     `عدد الأيام من ${specificDate.toDateString()} إلى اليوم الحالي هو ${dayDifference} يومًا.`
    // );

    return dayDifference
}


export function RepeatFunction(fn){

    let end = Math.floor(Math.random() * 10 + 1)
    let i = 0

    while (i < end) {

        fn()
        i++
        
    }

}
