export default {

    startDate: new Date("2023-04-01"),
    endDate: new Date("2023-05-15"),
    numberOfDates: 10,

};
