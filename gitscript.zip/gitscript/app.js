import fs from "node:fs";
import moment from "moment";
import { v4 as uuidv4 } from "uuid";
import config from "./config.js";

const startDate = config.startDate;
const endDate = config.endDate;
const numberOfDates = config.numberOfDates;

function generateRandomDates(startDate, endDate, numberOfDates = 1000) {
    const randomDates = [];
    const startMs = startDate.getTime();
    const endMs = endDate.getTime();

    for (let i = 0; i < numberOfDates; i++) {
        const randomMs = Math.floor(
            Math.random() * (endMs - startMs + 1) + startMs
        );

        const randomDate = new Date(randomMs);

        randomDates.push(randomDate);
    }

    return randomDates;
}

const randomDatesArray = generateRandomDates(startDate, endDate, numberOfDates);

randomDatesArray.forEach((el) => {

    const dt = moment(el).format("YYYY-MM-DD HH:MM:SS");

    fs.appendFile("dateList.txt", `${dt}#${uuidv4()}\n`, function (err) {
        if (err) throw err;
        //console.log("----");
    });
});


console.log('Mzian Tsna Choya ....')